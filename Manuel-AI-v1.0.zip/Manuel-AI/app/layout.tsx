import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title:"Manuel-AI", description:"Assistant IA conversationnel moderne." };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="fr"><body>{children}</body></html>}