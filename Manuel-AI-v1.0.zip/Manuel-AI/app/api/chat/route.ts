import {GoogleGenerativeAI} from "@google/generative-ai";
import {NextResponse} from "next/server";
export const runtime="nodejs";
export async function POST(req:Request){
 try{
  const body=await req.json(); const messages=Array.isArray(body.messages)?body.messages:[];
  if(!messages.length)return NextResponse.json({error:"Messages requis."},{status:400});
  if(!process.env.GEMINI_API_KEY)return NextResponse.json({error:"Service IA non configuré."},{status:503});
  const ai=new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
  const model=ai.getGenerativeModel({model:process.env.GEMINI_MODEL||"gemini-2.5-flash",systemInstruction:"Tu es Manuel-AI, un assistant clair, utile et honnête. Réponds en français sauf demande contraire."});
  const history=messages.slice(0,-1).map((m:any)=>({role:m.role==="assistant"?"model":"user",parts:[{text:String(m.content).slice(0,20000)}]}));
  const chat=model.startChat({history}); const last=messages[messages.length-1];
  const result=await chat.sendMessage(String(last.content).slice(0,20000));
  return NextResponse.json({content:result.response.text()});
 }catch(error){console.error("chat_error",error instanceof Error?error.message:"unknown");return NextResponse.json({error:"Impossible de contacter le service IA."},{status:500})}
}