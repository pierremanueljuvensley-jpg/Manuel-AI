# Manuel-AI v1.0
Assistant IA conversationnel avec Next.js, Supabase et Google Gemini.

## Installation
1. Copier `.env.example` vers `.env.local`.
2. Renseigner les variables Supabase et Gemini.
3. Exécuter `supabase/schema.sql` dans Supabase.
4. `npm install`
5. `npm run dev`

## Variables
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `GEMINI_API_KEY` — serveur uniquement
- `GEMINI_MODEL`

## API
- `GET /api/health`
- `POST /api/chat`

Ne commit jamais les fichiers `.env` ou les secrets.